import Vue from 'vue'
import Router from 'vue-router'

import { MapsPlugin, Legend, DataLabel, MapsTooltip } from '@syncfusion/ej2-vue-maps'
import 'material-design-icons-iconfont/dist/material-design-icons.css'


import FusionCharts from 'fusioncharts';
import Charts from 'fusioncharts/fusioncharts.charts';
import Widgets from 'fusioncharts/fusioncharts.widgets';
import PowerCharts from 'fusioncharts/fusioncharts.powercharts';
import FusionTheme from 'fusioncharts/themes/fusioncharts.theme.fusion';
import VueFusionCharts from 'vue-fusioncharts';

import LandingPage from '@/views/Site/LandingPage'
import Login from '@/views/Site/Login'
import SignUp from '@/views/Site/SignUp'

import UserHome from '@/views/Maps/UserHome'


// Font awesome
import { library } from '@fortawesome/fontawesome-svg-core'
import { FontAwesomeIcon } from '@fortawesome/vue-fontawesome'
import {
  faHome,faUser,faUserPlus,faSignInAlt,faSignOutAlt, faEye, faEyeSlash, faDatabase, faBars, faBrain, faSearch, faBell, faTrash, faCubes,
  faCog, faUserEdit, faEnvelope, faPlus, faChartLine, faFileDownload, faBookOpen, faHistory, faCode, faFile, faFolder, faFolderOpen, faPen,
  faPlay, faFileArchive, faEdit, faUpload, faArrowLeft, faStar, faDownload, faUserTimes, faMagic, faSmileBeam, faMeh, faFrown, faSave, faCalendarAlt,
  faClock, faCheck, faTimes, faCircleUser, faArrowDown, faArrowUp, faThumbsUp, faThumbsDown
} from '@fortawesome/free-solid-svg-icons';

library.add(
  faHome, faUser, faUserPlus, faSignInAlt, faSignOutAlt, faEye, faEyeSlash, faDatabase, faBars, faBrain, faSearch, faBell, faTrash, faCubes,
  faCog, faUserEdit, faEnvelope, faPlus, faChartLine, faFileDownload, faBookOpen, faHistory, faCode, faFile, faFolder, faFolderOpen, faPen,
  faPlay, faFileArchive, faEdit, faUpload, faArrowLeft, faStar, faDownload, faUserTimes, faMagic, faSmileBeam, faMeh, faFrown, faSave, faCalendarAlt,
  faClock, faCheck, faTimes, faCircleUser, faArrowDown, faArrowUp, faThumbsUp, faThumbsDown
);

Vue.use(Router)

Vue.use(MapsPlugin)

Vue.component('font-awesome-icon', FontAwesomeIcon)

Charts(FusionCharts);
PowerCharts(FusionCharts);
Widgets(FusionCharts);
FusionTheme(FusionCharts);

Vue.use(VueFusionCharts, FusionCharts);

Vue.component('font-awesome-icon', FontAwesomeIcon);

export default new Router({
  mode: 'history',
  routes: [
    { path: '/', name: 'LandingPage', component: LandingPage },
    { path: '/login', alias: '/signin', name: 'Login', component: Login },
    { path: '/signup', alias: '/register', name: 'SignUp', component: SignUp },
    { path: '/home', alias: '/map', name: 'UserHome', component: UserHome }
  ]
})
